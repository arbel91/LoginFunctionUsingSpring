package com.orax.solution.controllers;

import com.orax.solution.models.RegistrationRequest;
import com.orax.solution.services.RegistrationService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/")
@AllArgsConstructor
public class ApplicationController {
    private final RegistrationService registrationService;

    @PostMapping
    public String register(@RequestBody RegistrationRequest request){
        System.out.println(request.getFirstName());
        return registrationService.register(request);
    }
    @GetMapping("confirm")
    public String confirm(@RequestParam("token") String token){
        return registrationService.confirmToken(token);
    }
    @GetMapping("login")
    public String getLogin(){
        return "login";
    }
}
