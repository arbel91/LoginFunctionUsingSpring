package com.orax.solution.models;

public enum AppUserRole {
    USER,
    ADMIN
}
