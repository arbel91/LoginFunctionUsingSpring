package com.orax.solution.email;

public interface EmailSender {
    void send(String to,String email);
}
